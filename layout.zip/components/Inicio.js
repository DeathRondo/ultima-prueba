import React from 'react'
import { Link } from 'react-router-dom'

export const Inicio = () => {
  return (
    <div className='headernav'>
      
      <h1 className='info__name'>
        Edgardo Cruz
      </h1>
      <h2 className='info__job'>
      Desarrollador web
        {/* diversos tipos de proyectos de <strong>aplicaciones Web.</strong> <Link to="/contacto">Contacta conmigo.</Link> */}
      </h2>
      <section>
        {/* <h2 className='heading'>Algunos de mis proyectos</h2>
        <p>Estos son algunos de mis trabajos de desarrollo web.</p> */}

        
      </section>


    </div>
  )
}
